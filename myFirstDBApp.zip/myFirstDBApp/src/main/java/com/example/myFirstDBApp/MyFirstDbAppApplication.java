package com.example.myFirstDBApp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MyFirstDbAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(MyFirstDbAppApplication.class, args);
	}

}
