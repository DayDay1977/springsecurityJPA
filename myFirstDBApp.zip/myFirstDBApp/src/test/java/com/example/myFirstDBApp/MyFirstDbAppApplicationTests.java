package com.example.myFirstDBApp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MyFirstDbAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
